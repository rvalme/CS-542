'''
    File name: customer_order.py
    Author: Chu Wang
    Date Created: 3/29/2018
    Date last modified: 3/29/2018
    Python Version:3.6
'''